import React from 'react';

const Cse = () => {
  return (
    <div>
      <h1>Welcome to CSE</h1>

      
    </div>
  );
};

export default Cse;
