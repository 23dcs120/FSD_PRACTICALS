import React from 'react';

const Depstar = () => {
  return (
    <div>
      <h1>Welcome to DEPSTAR</h1>
      
    </div>
  );
};

export default Depstar;
