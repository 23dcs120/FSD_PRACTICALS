import React from 'react';

const Charusat = () => {
  return (
    <div>
      <h1>Welcome to CHARUSAT</h1>
     
    </div>
  );
};

export default Charusat;
