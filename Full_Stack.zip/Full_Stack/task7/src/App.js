import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import './App.css';

const Charusat = () => <h1>Welcome to CHARUSAT</h1>;
const Depstar = () => <h1>Welcome to DEPSTAR</h1>;
const Cse = () => <h1>Welcome to CSE</h1>;

function App() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <Router>
      <div className="app">
        <div className={`sidebar ${isOpen ? 'open' : ''}`}>
          <nav>
            <Link to="/charusat" onClick={() => setIsOpen(false)}>Welcome to CHARUSAT</Link>
            <Link to="/depstar" onClick={() => setIsOpen(false)}>Welcome to DEPSTAR</Link>
            <Link to="/cse" onClick={() => setIsOpen(false)}>Welcome to CSE</Link>
          </nav>
        </div>

        <button
          className="toggle-btn"
          onClick={() => setIsOpen(!isOpen)}
        >
          &#9776;
        </button>

        <div className="main-content">
          <Routes>
            <Route path="/" element={<Charusat />} />
            <Route path="/charusat" element={<Charusat />} />
            <Route path="/depstar" element={<Depstar />} />
            <Route path="/cse" element={<Cse />} />
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;
