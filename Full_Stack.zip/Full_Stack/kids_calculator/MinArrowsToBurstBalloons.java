import java.util.*;

class MinArrowsToBurstBalloons {

    public static int findMinArrowShots(int[][] points) {
        if (points.length == 0) return 0;

        
        Arrays.sort(points, (a, b) -> Integer.compare(a[1], b[1]));

        int arrows = 1;
        long arrowPos = points[0][1];

        for (int[] balloon : points) {
            if (balloon[0] > arrowPos) {
                arrows++;
                arrowPos = balloon[1];
            }
        }
        return arrows;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of balloons: ");
        int n = sc.nextInt();

        int[][] points = new int[n][2];
        System.out.println("Enter the balloons as x_start x_end:");
        for (int i = 0; i < n; i++) {
            points[i][0] = sc.nextInt();
            points[i][1] = sc.nextInt();
        }

        int result = findMinArrowShots(points);
        System.out.println("Minimum arrows needed: " + result);

        sc.close();
    }
}
