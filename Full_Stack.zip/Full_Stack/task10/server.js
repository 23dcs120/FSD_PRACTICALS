const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const logFilePath = path.join(__dirname, 'error.log');

app.get('/', (req, res) => {
  fs.readFile(logFilePath, 'utf8', (err, data) => {
    if (err) {
      console.error('Error reading log file:', err.message);
      return res.status(500).send('<h1>Error: Unable to read log file.</h1>');
    }

    res.send(`
      <h1>Server Error Logs</h1>
      <pre style="background-color:#f4f4f4; padding:10px; border-radius:5px;">
${data}
      </pre>
    `);
  });
});

app.listen(PORT, () => {
  console.log(`Log Viewer running at http://localhost:${PORT}`);
});
