import React, { useState } from 'react';
import './CreateTask.css';

function CreateTask() {
  const [task, setTask] = useState('');
  const [tasks, setTasks] = useState([]);

  const addTask = () => {
    if (task.trim()) {
      setTasks([...tasks, { text: task, completed: false, isEditing: false }]);
      setTask('');
    }
  };

  const deleteTask = (index) => {
    const newTasks = tasks.filter((_, i) => i !== index);
    setTasks(newTasks);
  };

  const toggleComplete = (index) => {
    const updatedTasks = [...tasks];
    updatedTasks[index].completed = !updatedTasks[index].completed;
    setTasks(updatedTasks);
  };

  const toggleEdit = (index) => {
    const updatedTasks = [...tasks];
    updatedTasks[index].isEditing = !updatedTasks[index].isEditing;
    setTasks(updatedTasks);
  };

  const handleEditChange = (e, index) => {
    const updatedTasks = [...tasks];
    updatedTasks[index].text = e.target.value;
    setTasks(updatedTasks);
  };

  const totalTasks = tasks.length;
  const pendingTasks = tasks.filter((t) => !t.completed).length;
  const completedTasks = tasks.filter((t) => t.completed).length;

  return (
    <div className="todo-container">
      <h2>Get Things Done!</h2>
      <div className="input-section">
        <input
          type="text"
          placeholder="What is the task today?"
          value={task}
          onChange={(e) => setTask(e.target.value)}
        />
        <button onClick={addTask}>Add Task</button>
      </div>

      <div className="task-stats">
        <p>Total Tasks: {totalTasks}</p>
        <p>Pending Tasks: {pendingTasks}</p>
        <p>Completed Tasks: {completedTasks}</p>
      </div>

      <ul className="task-list">
        {tasks.map((t, index) => (
          <li key={index} className={t.completed ? 'completed' : ''}>
            {t.isEditing ? (
              <input
                type="text"
                value={t.text}
                onChange={(e) => handleEditChange(e, index)}
                onBlur={() => toggleEdit(index)}
                autoFocus
              />
            ) : (
              <span onDoubleClick={() => toggleEdit(index)}>{t.text}</span>
            )}
            <div className="action-buttons">
              {!t.isEditing && (
                <button className="complete-btn" onClick={() => toggleComplete(index)}>
                  {t.completed ? 'Undone' : 'Done'}
                </button>
              )}
              <button className="edit-btn" onClick={() => toggleEdit(index)}>
                {t.isEditing ? 'Save' : 'Edit'}
              </button>
              <button className="delete-btn" onClick={() => deleteTask(index)}>Delete</button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default CreateTask;
