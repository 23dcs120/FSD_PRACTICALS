import React from 'react';
import CreateTask from './CreateTask';

function App() {
  return (
    <div>
      <CreateTask />
    </div>
  );
}

export default App;
