let count = localStorage.getItem('repCount') || 0;
count = parseInt(count);
document.getElementById("counter").innerText = count;

function increase() {
  count++;
  update();
}

function decrease() {
  if (count > 0) count--;
  update();
}

function reset() {
  count = 0;
  update();
}

function update() {
  document.getElementById("counter").innerText = count;
  localStorage.setItem('repCount', count);
}
