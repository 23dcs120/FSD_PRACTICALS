import React from 'react';
import CounterApp from './CounterApp';

function App() {
  return <CounterApp />;
}

export default App;
