
import React from "react";
import "./App.css"; 
import Practical from "./Practical"; 

function App() {
  return (
    <div className="App">
      <Practical />
    </div>
  );
}

export default App;
