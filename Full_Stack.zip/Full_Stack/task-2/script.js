
const weatherData = {
  ahmedabad: { temp: 40, condition: "Sunny" },
  vadodara: { temp: 38, condition: "Clear" },
  surat: { temp: 36, condition: "Cloudy" },
  mumbai: { temp: 33, condition: "Humid" },
  delhi: { temp: 35, condition: "Hazy" },
  bengaluru: { temp: 28, condition: "Rainy" }
};

const getWeatherBtn = document.getElementById("getWeatherBtn");
const cityInput = document.getElementById("cityInput");
const weatherResult = document.getElementById("weatherResult");

getWeatherBtn.addEventListener("click", () => {
  const city = cityInput.value.trim().toLowerCase();

  if (city === "") {
    weatherResult.textContent = "Please enter a city name.";
    return;
  }

  const data = weatherData[city];

  if (data) {
    weatherResult.innerHTML = `The weather in <strong>${city.charAt(0).toUpperCase() + city.slice(1)}</strong> is <strong>${data.temp}°C</strong> and it's <strong>${data.condition}</strong>.`;
  } else {
    weatherResult.textContent = `Weather data for "${city}" not found.`;
  }
});
