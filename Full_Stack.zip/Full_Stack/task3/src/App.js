import React from 'react';
import DateTimeDisplay from './DateTimeDisplay';

function App() {
  return <DateTimeDisplay />;
}

export default App;
