import React, { useState, useEffect } from "react";
import "./App.css";

const feedbackOptions = ["Excellent", "Good", "Average", "Poor"];

const App = () => {
 
  const [firstName, setFirstName] = useState("");
  const [surname, setSurname] = useState("");


  const [currentTime, setCurrentTime] = useState(new Date());

  const [feedbackCounts, setFeedbackCounts] = useState({
    Excellent: 0,
    Good: 0,
    Average: 0,
    Poor: 0,
  });

  const [userCounter, setUserCounter] = useState(0);

 
  const handleInputChange = (e, setter) => setter(e.target.value);

 
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

 
  useEffect(() => {
    const randomVote = setInterval(() => {
      const option = feedbackOptions[Math.floor(Math.random() * 4)];
      setFeedbackCounts(prev => ({
        ...prev,
        [option]: prev[option] + 1,
      }));
    }, 2000);
    return () => clearInterval(randomVote);
  }, []);


  const handleFeedback = (type) => {
    setFeedbackCounts(prev => ({
      ...prev,
      [type]: prev[type] + 1,
    }));
    setUserCounter(prev => prev + 1);
  };

 
  const increment = () => setUserCounter(prev => prev + 1);
  const decrement = () => setUserCounter(prev => (prev > 0 ? prev - 1 : 0));
  const reset = () => setUserCounter(0);
  const incrementFive = () => setUserCounter(prev => prev + 5);

  return (
    <div className="app-container">
      <h1>🎤 Live Event Feedback Dashboard</h1>

      {}
      <div className="greeting-section">
        <input
          type="text"
          placeholder="First Name"
          value={firstName}
          onChange={(e) => handleInputChange(e, setFirstName)}
        />
        <input
          type="text"
          placeholder="Surname"
          value={surname}
          onChange={(e) => handleInputChange(e, setSurname)}
        />
        {firstName && surname && (
          <h2 className="welcome-text">➤ Welcome, {firstName} {surname}!</h2>
        )}
      </div>

      {}
      <div className="clock-section">
        <h3>🕒 Current Time: {currentTime.toLocaleString()}</h3>
      </div>

      {}
      <div className="feedback-panel">
        <h2>🗳️ Give Your Feedback:</h2>
        {feedbackOptions.map(option => (
          <button key={option} onClick={() => handleFeedback(option)}>
            {option}
          </button>
        ))}
        <div className="feedback-results">
          {feedbackOptions.map(option => (
            <p key={option}>
              {option}: {feedbackCounts[option]}
            </p>
          ))}
        </div>
      </div>

      {}
      <div className="counter-panel">
        <h2>📊 Your Submission Counter: {userCounter}</h2>
        <button onClick={increment}>Increment</button>
        <button onClick={decrement}>Decrement</button>
        <button onClick={reset}>Reset</button>
        <button onClick={incrementFive}>Increment by 5</button>
      </div>
    </div>
  );
};

export default App;
